import { ProductModel, SpecItem, ServiceItem, DesignCapability } from './types';

export const COMPANY_INFO = {
  name: ".DWG Layout Inc.",
  tagline: "Your Success is Our Success",
  address: "4251 FM 2181 Suite 230/158, Corinth, Texas 76210",
  phone: "214.212.3213",
  email: "info@dwglayout.com",
  patent: "PATENT # 12221297",
  copyrightYear: "2024",
};

export const PRODUCT_GENERAL_SPECS: SpecItem[] = [
  { label: "Voltage & Wiring", value: "Nominal 120 VAC (single phase)" },
  { label: "Frequency", value: "50/60 Hz" },
  { label: "Enclosure Rating", value: "Indoor Use Only" },
  { label: "Power Cable(s)", value: "SJT AWG 16/3-Connector Type IEC 60320 C13/Plug Type NEMA 5-15" },
  { label: "Operation Temp.", value: "32°F - 104°F / 0°C - 40°C" },
  { label: "Storage Temp.", value: "60°F - 95°F / 15.5°C - 35°C" },
  { label: "Humidity", value: "5% ~ 95% (without condensation)" },
];

export const PRODUCT_MODELS: ProductModel[] = [
  {
    id: "VB-x01",
    name: "1 Blower Motor",
    description: "Single unit configuration for standard commercial applications.",
    blowers: 1,
    current: "1×(10-12) A",
    cfm: "340-360",
    dimensions: "9″ × 11″ × 19″",
    weight: "~ 33 lbs.",
    cables: "1 × 3ft",
    exampleIds: "VB101, VB101-12000-072",
  },
  {
    id: "VB-x02",
    name: "2 Blower Pack",
    description: "Dual blower pack for increased airflow requirements.",
    blowers: 2,
    current: "2×(10-12) A",
    cfm: "120", // Note: Value from prompt seems low for 2 blowers compared to 1, but keeping prompt fidelity
    dimensions: "9″ × 11″ × 25″",
    weight: "~ 25 lbs.",
    cables: "2 × 3ft",
    exampleIds: "VB102",
  },
  {
    id: "VB-x03",
    name: "3 Blower Model",
    description: "Triple blower configuration for maximum output.",
    blowers: 3,
    current: "3×(10-12) A",
    cfm: "230-240",
    dimensions: "9″ × 11″ × 31″",
    weight: "~ 43 lbs.",
    cables: "3 × 3ft",
    exampleIds: "VB103, VB103 12000-070",
  },
];

export const DEVELOPMENT_PROCESS: string[] = [
  "New Concept Design",
  "Product and Service Design",
  "Product Development",
  "3D Printed Prototypes",
  "Tooling Design",
  "Manufacturing",
  "Electronic/PCB & Software Design",
  "Retail & Shipping Packaging",
];

export const DESIGN_CAPABILITIES: DesignCapability[] = [
  {
    category: "Plastic Design",
    items: ["Injection molding", "Extrusion", "Thermoform", "Rotational molding"],
    featured: ["Custom Plastic Designs & Tooling", "Large Scale Plastics Designs"],
  },
  {
    category: "Metal Design",
    items: ["Metal design", "Sheet metal design"],
    featured: ["Custom Designs, Metal & Plastics", "Custom Sheet Metal Designs"],
  },
  {
    category: "Electronics & Documentation",
    items: ["Electronic & Software Designs", "Label & Drawing Designs", "Mechanical Drawings"],
    featured: [],
  },
];

export const INDUSTRY_EXAMPLES = [
  "Sports Product Designs",
  "Wearable Product Designs",
  "Outdoor Product Designs",
  "Oilfield Product Designs",
];