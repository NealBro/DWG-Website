export interface ProductModel {
  id: string;
  name: string;
  description: string;
  blowers: number;
  current: string;
  cfm: string;
  dimensions: string;
  weight: string;
  cables: string;
  exampleIds: string;
}

export interface SpecItem {
  label: string;
  value: string;
}

export interface ServiceItem {
  title: string;
  description?: string;
}

export interface DesignCapability {
  category: string;
  items: string[];
  featured: string[];
}