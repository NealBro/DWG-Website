import React from 'react';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';
import { COMPANY_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Header */}
      <div className="bg-brand-primary py-12 text-center text-white">
        <h1 className="text-4xl font-bold mb-4">Contact Us</h1>
        <p className="text-xl text-gray-300">We are here to help you succeed.</p>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Info Side */}
          <div>
             <h2 className="text-2xl font-bold text-brand-dark mb-8">Get In Touch</h2>
             <div className="space-y-8">
               <div className="flex items-start">
                 <div className="bg-brand-accent/10 p-3 rounded-lg mr-4">
                   <MapPin className="w-6 h-6 text-brand-accent" />
                 </div>
                 <div>
                   <h3 className="font-bold text-lg text-brand-dark">Visit Us</h3>
                   <p className="text-gray-600">{COMPANY_INFO.address}</p>
                 </div>
               </div>

               <div className="flex items-start">
                 <div className="bg-brand-accent/10 p-3 rounded-lg mr-4">
                   <Phone className="w-6 h-6 text-brand-accent" />
                 </div>
                 <div>
                   <h3 className="font-bold text-lg text-brand-dark">Call Us</h3>
                   <p className="text-gray-600">
                     <a href={`tel:${COMPANY_INFO.phone}`} className="hover:text-brand-accent transition-colors">
                       {COMPANY_INFO.phone}
                     </a>
                   </p>
                 </div>
               </div>

               <div className="flex items-start">
                 <div className="bg-brand-accent/10 p-3 rounded-lg mr-4">
                   <Mail className="w-6 h-6 text-brand-accent" />
                 </div>
                 <div>
                   <h3 className="font-bold text-lg text-brand-dark">Email Us</h3>
                   <p className="text-gray-600">
                     <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-brand-accent transition-colors">
                       {COMPANY_INFO.email}
                     </a>
                   </p>
                 </div>
               </div>
               
               <div className="flex items-start">
                 <div className="bg-brand-accent/10 p-3 rounded-lg mr-4">
                   <Clock className="w-6 h-6 text-brand-accent" />
                 </div>
                 <div>
                   <h3 className="font-bold text-lg text-brand-dark">Business Hours</h3>
                   <p className="text-gray-600">Monday - Friday: 8:00 AM - 5:00 PM CST</p>
                 </div>
               </div>
             </div>
          </div>

          {/* Form Side (Visual Only) */}
          <div className="bg-gray-50 p-8 rounded-xl border border-gray-200 shadow-sm">
            <h2 className="text-2xl font-bold text-brand-dark mb-6">Send a Message</h2>
            <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input type="text" className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none" placeholder="John" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input type="text" className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none" placeholder="Doe" />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none" placeholder="john@company.com" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <select className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none bg-white">
                  <option>Product Inquiry (Valve-Blower Series)</option>
                  <option>Consulting Services</option>
                  <option>Support</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <textarea className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none h-32" placeholder="How can we help you?"></textarea>
              </div>

              <button className="w-full bg-brand-dark text-white font-bold py-3 rounded hover:bg-brand-primary transition-colors">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;