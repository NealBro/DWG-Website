import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Settings, Users, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-brand-dark text-white py-24 md:py-32 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
            {/* Abstract Background Image */}
           <img 
            src="https://picsum.photos/id/1/1920/1080" 
            alt="Engineering background" 
            className="w-full h-full object-cover grayscale"
           />
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight">
            {COMPANY_INFO.name}
          </h1>
          <p className="text-xl md:text-3xl text-brand-accent font-light mb-8 italic">
            "{COMPANY_INFO.tagline}"
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Link 
              to="/products" 
              className="bg-brand-accent hover:bg-sky-500 text-white font-bold py-3 px-8 rounded-lg transition-colors flex items-center justify-center"
            >
              View Products
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <Link 
              to="/contact" 
              className="bg-transparent border-2 border-white hover:bg-white hover:text-brand-dark text-white font-bold py-3 px-8 rounded-lg transition-all flex items-center justify-center"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>

      {/* Intro Features */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 bg-gray-50 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 text-brand-accent rounded-full flex items-center justify-center mb-4">
                <Settings className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-brand-dark">Innovative Solutions</h3>
              <p className="text-gray-600">
                Delivering cost-effective design and manufacturing solutions through innovative methods and skilled experience.
              </p>
            </div>
            
            <div className="p-6 bg-gray-50 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 text-brand-accent rounded-full flex items-center justify-center mb-4">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-brand-dark">Engineering Extension</h3>
              <p className="text-gray-600">
                Acting as a dedicated extension of your engineering resources since 1996, from concept to product readiness.
              </p>
            </div>

            <div className="p-6 bg-gray-50 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 text-brand-accent rounded-full flex items-center justify-center mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-brand-dark">Quality Assurance</h3>
              <p className="text-gray-600">
                Made in USA options with capabilities extending to global manufacturing partnerships for scalability.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Product Teaser */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
             <img 
               src="https://picsum.photos/seed/tech/600/400" 
               alt="Valve-Blower Series" 
               className="rounded-lg shadow-2xl opacity-90 border-2 border-gray-700"
             />
          </div>
          <div className="md:w-1/2 md:pl-12">
            <span className="text-brand-accent font-bold tracking-wider uppercase text-sm mb-2 block">Featured Product</span>
            <h2 className="text-3xl font-bold mb-4">Valve-Blower Series</h2>
            <p className="text-gray-300 mb-6 text-lg">
              Universal Drive-Thru Equipment engineered for easy in-field replacement or upgrading of pneumatic blowers.
            </p>
            <ul className="mb-8 space-y-2">
               <li className="flex items-center text-gray-300">
                 <span className="w-2 h-2 bg-brand-accent rounded-full mr-2"></span>
                 Made in USA
               </li>
               <li className="flex items-center text-gray-300">
                 <span className="w-2 h-2 bg-brand-accent rounded-full mr-2"></span>
                 Commercial Application
               </li>
               <li className="flex items-center text-gray-300">
                 <span className="w-2 h-2 bg-brand-accent rounded-full mr-2"></span>
                 Multiple Configurations (1-3 Blowers)
               </li>
            </ul>
            <Link 
              to="/products" 
              className="inline-block border-b-2 border-brand-accent pb-1 text-white hover:text-brand-accent transition-colors"
            >
              View Technical Specifications &rarr;
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;