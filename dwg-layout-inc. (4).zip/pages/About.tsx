import React from 'react';
import { CheckCircle2, Factory, Globe, Lightbulb } from 'lucide-react';
import { DEVELOPMENT_PROCESS, DESIGN_CAPABILITIES, INDUSTRY_EXAMPLES } from '../constants';

const About: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Header */}
      <div className="bg-gray-100 py-12 border-b border-gray-200">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-brand-dark mb-4">About Us</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            Consulting Design Services & Product Development. Your trusted engineering extension since 1996.
          </p>
        </div>
      </div>

      {/* Company Overview */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-2xl font-bold text-brand-dark mb-6">Who We Are</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                <strong>.DWG Layout Inc.</strong> is a premier Consulting Design Services and Product Development Company. 
                For nearly three decades, we have acted as a seamless extension to our clients' engineering resources.
              </p>
              <p>
                We specialize in full-service Product Design and Manufacturing, taking your idea from 
                <strong> Concept Design to Product Readiness</strong>. We spearhead all aspects of your product vision, 
                ensuring quality, efficiency, and market readiness.
              </p>
              <div className="bg-brand-accent/10 p-4 border-l-4 border-brand-accent rounded-r-lg mt-6">
                <p className="font-semibold text-brand-dark">
                  Value Proposition:
                </p>
                <p className="italic text-gray-600">
                  "We are able to provide the best cost-effective solutions due to our innovative delivery of methods, skills, and experience."
                </p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
             <img src="https://picsum.photos/seed/draft/400/300" alt="Drafting" className="rounded-lg shadow-md w-full h-48 object-cover" />
             <img src="https://picsum.photos/seed/engineer/400/300" alt="Engineering" className="rounded-lg shadow-md w-full h-48 object-cover mt-8" />
          </div>
        </div>
      </section>

      {/* Development Process */}
      <section className="bg-brand-dark text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Concept to Production</h2>
            <p className="text-gray-400">The stages we manage when spearheading your product vision.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {DEVELOPMENT_PROCESS.map((step, index) => (
              <div key={index} className="bg-brand-primary p-6 rounded-lg border border-gray-700 hover:border-brand-accent transition-colors relative group">
                <div className="absolute top-4 right-4 text-brand-dark/20 text-4xl font-bold group-hover:text-brand-accent/20 transition-colors">
                  {index + 1}
                </div>
                <h3 className="text-lg font-semibold relative z-10">{step}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Capabilities */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-3xl font-bold text-brand-dark mb-10 text-center">Specialized Design Capabilities</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {DESIGN_CAPABILITIES.map((cap) => (
            <div key={cap.category} className="border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-lg transition-shadow bg-white">
              <h3 className="text-xl font-bold text-brand-accent mb-4 border-b pb-2">{cap.category}</h3>
              <ul className="space-y-2 mb-6">
                {cap.items.map((item, i) => (
                  <li key={i} className="flex items-center text-gray-700">
                    <CheckCircle2 className="w-4 h-4 text-green-500 mr-2 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              {cap.featured.length > 0 && (
                <div className="bg-gray-50 p-3 rounded text-sm">
                  <span className="font-semibold block mb-1 text-gray-900">Featured Titles:</span>
                  <ul className="list-disc list-inside text-gray-600">
                    {cap.featured.map((feat, i) => (
                      <li key={i}>{feat}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Showcases & Manufacturing */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
             {/* Examples */}
             <div>
                <div className="flex items-center mb-6">
                  <Lightbulb className="w-8 h-8 text-brand-accent mr-3" />
                  <h2 className="text-2xl font-bold text-brand-dark">Industry Showcase</h2>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {INDUSTRY_EXAMPLES.map((ex, i) => (
                      <li key={i} className="flex items-center p-3 bg-gray-50 rounded border border-gray-100">
                        <span className="w-2 h-2 bg-brand-dark rounded-full mr-3"></span>
                        {ex}
                      </li>
                    ))}
                  </ul>
                </div>
             </div>

             {/* Manufacturing */}
             <div>
                <div className="flex items-center mb-6">
                  <Globe className="w-8 h-8 text-brand-accent mr-3" />
                  <h2 className="text-2xl font-bold text-brand-dark">Manufacturing Reach</h2>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 h-full">
                  <p className="text-lg text-gray-700 mb-4">
                    We offer flexible manufacturing capabilities to suit your scale and budget requirements.
                  </p>
                  <div className="flex flex-col space-y-4">
                    <div className="flex items-center">
                      <Factory className="w-6 h-6 text-brand-primary mr-3" />
                      <span className="font-semibold text-brand-dark">Local Manufacturing (USA)</span>
                    </div>
                    <div className="flex items-center">
                      <Globe className="w-6 h-6 text-brand-primary mr-3" />
                      <span className="font-semibold text-brand-dark">Overseas Manufacturing (China)</span>
                    </div>
                  </div>
                </div>
             </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default About;