import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { ArrowLeft, Box, Zap, Wind, Scale, Cable, AlertTriangle, FileText } from 'lucide-react';
import { PRODUCT_MODELS } from '../constants';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const product = PRODUCT_MODELS.find(p => p.id === id);

  if (!product) {
    return <Navigate to="/products" replace />;
  }

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Back Link */}
        <Link to="/products" className="inline-flex items-center text-gray-500 hover:text-brand-accent mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Series Overview
        </Link>

        {/* Header */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8">
          <div className="md:flex">
            <div className="md:w-1/3 h-64 md:h-auto relative">
               <img 
                 src={`https://picsum.photos/seed/${product.id}/800/800`} 
                 alt={product.name}
                 className="w-full h-full object-cover"
               />
               <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded text-sm font-bold shadow-sm">
                 Model: {product.id}
               </div>
            </div>
            <div className="md:w-2/3 p-8 md:p-12 flex flex-col justify-center">
              <h1 className="text-3xl md:text-4xl font-bold text-brand-dark mb-4">{product.name}</h1>
              <p className="text-xl text-gray-600 mb-6">{product.description}</p>
              
              <div className="inline-flex flex-wrap gap-2">
                 {product.exampleIds.split(',').map((eid, i) => (
                   <span key={i} className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm border border-gray-200">
                     ID: {eid.trim()}
                   </span>
                 ))}
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Specs */}
          <div className="md:col-span-2 space-y-8">
            
            {/* Spec Cards */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              <h2 className="text-2xl font-bold text-brand-dark mb-6 flex items-center">
                <FileText className="w-6 h-6 mr-3 text-brand-accent" />
                Technical Specifications
              </h2>
              
              <div className="grid sm:grid-cols-2 gap-6">
                 <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Zap className="w-4 h-4 mr-2" />
                      <span className="text-sm font-semibold uppercase">Current per Supply</span>
                    </div>
                    <p className="text-lg font-bold text-brand-dark">{product.current}</p>
                 </div>

                 <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Wind className="w-4 h-4 mr-2" />
                      <span className="text-sm font-semibold uppercase">Airflow (CFM)</span>
                    </div>
                    <p className="text-lg font-bold text-brand-dark">{product.cfm}</p>
                 </div>

                 <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Box className="w-4 h-4 mr-2" />
                      <span className="text-sm font-semibold uppercase">Dimensions (H" x W" x L")</span>
                    </div>
                    <p className="text-lg font-bold text-brand-dark">{product.dimensions}</p>
                 </div>

                 <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Scale className="w-4 h-4 mr-2" />
                      <span className="text-sm font-semibold uppercase">Weight (Approx.)</span>
                    </div>
                    <p className="text-lg font-bold text-brand-dark">{product.weight}</p>
                 </div>

                 <div className="p-4 bg-gray-50 rounded-lg sm:col-span-2">
                    <div className="flex items-center text-gray-500 mb-2">
                      <Cable className="w-4 h-4 mr-2" />
                      <span className="text-sm font-semibold uppercase">Cable Quantities & Length</span>
                    </div>
                    <p className="text-lg font-bold text-brand-dark">{product.cables}</p>
                 </div>
              </div>
            </div>

            {/* Crucial Component Note */}
            <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg">
              <h3 className="text-blue-900 font-bold text-lg mb-2">Crucial Component Note</h3>
              <p className="text-blue-800">
                Each Model features a unique <strong>Blower Control Panel</strong> which includes the Blower Power Input(s) 
                and Pneumatic System Control Input.
              </p>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Warning Box */}
            <div className="bg-red-50 border border-red-200 rounded-xl p-6 shadow-sm">
              <div className="flex items-center mb-4 text-red-600">
                <AlertTriangle className="w-8 h-8 mr-3" />
                <h3 className="text-xl font-bold">WARNING</h3>
              </div>
              <p className="text-red-800 font-medium mb-4">
                Strict adherence to electrical requirements is mandatory.
              </p>
              <ul className="list-disc list-inside text-red-700 space-y-1 text-sm">
                 <li>Voltage: 120 VAC</li>
                 <li>Frequency: 60Hz</li>
                 <li>Amperage: 15A</li>
                 <li>Indoor Use Only</li>
              </ul>
            </div>

            {/* Contact CTA */}
            <div className="bg-brand-dark text-white rounded-xl p-6 shadow-lg">
              <h3 className="text-xl font-bold mb-3">Need Customization?</h3>
              <p className="text-gray-300 mb-6 text-sm">
                We offer custom design services to fit your specific engineering requirements.
              </p>
              <Link to="/contact" className="block w-full bg-brand-accent hover:bg-sky-400 text-white text-center py-3 rounded font-bold transition-colors">
                Contact Engineering
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;