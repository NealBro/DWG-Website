import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, AlertTriangle } from 'lucide-react';
import { PRODUCT_GENERAL_SPECS, PRODUCT_MODELS } from '../constants';

const Products: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Product Hero */}
      <section className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Valve-Blower Series</h1>
          <p className="text-xl text-gray-300 mb-2">Universal Drive-Thru Equipment</p>
          <span className="inline-block bg-brand-accent text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
            Made in USA
          </span>
        </div>
      </section>

      {/* Main Overview */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-2xl font-bold text-brand-dark mb-4">Overview</h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            Engineered for easy in-field replacement or upgrading of pneumatic blowers. 
            Designed for commercial applications with robust enclosures and reliable performance.
          </p>
        </div>

        {/* General Specs Table */}
        <div className="mb-20">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-brand-dark">General Technical Specifications</h3>
            <span className="text-sm text-gray-500 italic">Applies to all models</span>
          </div>
          
          <div className="overflow-x-auto bg-white shadow-lg rounded-lg border border-gray-200">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-100 border-b border-gray-200">
                  <th className="p-4 font-semibold text-brand-dark w-1/3">Specification</th>
                  <th className="p-4 font-semibold text-brand-dark">Detail</th>
                </tr>
              </thead>
              <tbody>
                {PRODUCT_GENERAL_SPECS.map((spec, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                    <td className="p-4 border-b border-gray-100 font-medium text-gray-700">{spec.label}</td>
                    <td className="p-4 border-b border-gray-100 text-gray-600">{spec.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Models Grid */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-brand-dark mb-8 text-center">Available Models</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {PRODUCT_MODELS.map((model) => (
              <div key={model.id} className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden hover:shadow-xl transition-shadow flex flex-col">
                <div className="h-48 bg-gray-100 flex items-center justify-center relative">
                   {/* Placeholder for product image */}
                   <img 
                    src={`https://picsum.photos/seed/${model.id}/400/300`} 
                    alt={model.name}
                    className="w-full h-full object-cover"
                   />
                   <div className="absolute bottom-0 left-0 bg-brand-primary text-white text-xs px-3 py-1 font-mono">
                     {model.id}
                   </div>
                </div>
                
                <div className="p-6 flex-grow flex flex-col">
                  <h4 className="text-xl font-bold text-brand-dark mb-2">{model.name}</h4>
                  <p className="text-gray-600 text-sm mb-6 flex-grow">{model.description}</p>
                  
                  <div className="space-y-2 mb-6 text-sm text-gray-700">
                    <div className="flex justify-between border-b border-gray-100 pb-1">
                      <span>Blowers:</span>
                      <span className="font-semibold">{model.blowers}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-1">
                      <span>CFM:</span>
                      <span className="font-semibold">{model.cfm}</span>
                    </div>
                  </div>

                  <Link 
                    to={`/products/${model.id}`}
                    className="w-full bg-brand-dark hover:bg-brand-accent text-white py-2 px-4 rounded text-center transition-colors flex items-center justify-center font-medium"
                  >
                    View Details
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Warnings / Notes */}
        <div className="bg-brand-warning/10 border-l-4 border-brand-warning p-6 rounded-r-lg max-w-4xl mx-auto">
          <div className="flex items-start">
             <AlertTriangle className="w-6 h-6 text-brand-warning mr-4 mt-1 shrink-0" />
             <div>
               <h4 className="font-bold text-brand-dark text-lg mb-2">Important Safety Information</h4>
               <p className="text-gray-800">
                 Please ensure electrical requirements are met (120 VAC 60Hz 15A). 
                 Each model features a unique Blower Control Panel which includes the Blower Power Input(s) 
                 and Pneumatic System Control Input.
               </p>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Products;